package assembler;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;

public class Assembler extends PApplet {
	
	public static void main(String[] args) {
		PApplet.main("assembler.Assembler");
	}
	
	public void settings() {
		size(600, 200);
	}
	
	GUI.Button selectSrc;
	GUI.Button selectAsmg;
	GUI.Button selectOut;
	GUI.Button compile;
	GUI.Button openDump;
	String srcPath = "";
	String asmgPath = "";
	String outPath = "";
	String argCont = "";
	InstructionSet IS;
	
	float progress = 0.5f;
	String progText = "Sample text.";
	boolean progEnabled = false;
	
	String error0 = "";
	String error1 = "";
	
	/*
	Todos:
	*/
	
	public void setup() {
		String[] s = loadStrings("data/paths.txt");
		if (s != null && s.length == 3) {
			srcPath = s[0];
			asmgPath = s[1];
			outPath = s[2];
			selAsmg(new File(asmgPath));
		}
		GUI gui = new GUI();
		PApplet app = this;
		selectSrc = gui.new Button(100, 5, 50, 20, "select", false, new Runnable() {
			public void run() {
				selectInput("select source code file...", "selSrc", null, app);
			}
		});
		selectAsmg = gui.new Button(100, 35, 50, 20, "select", false, new Runnable() {
			public void run() {
				selectInput("select assembly guide file...", "selAsmg", null, app);
			}
		});
		selectOut = gui.new Button(100, 65, 50, 20, "select", false, new Runnable() {
			public void run() {
				selectOutput("select output name...", "selOut", null, app);
			}
		});
		compile = gui.new Button(5, 95, 60, 20, "compile", false, new Runnable() {
			public void run() {
				if (loadStrings(asmgPath) == null) {
					error0 = "missing assembly guide";
					return;
				}
				if (loadStrings(srcPath) == null) {
					error0 = "missing source code";
					return;
				}
				compile();
				String[] s = {
						srcPath,
						asmgPath,
						outPath
				};
				saveStrings("data/paths.txt", s);
			}
		});
		openDump = gui.new Button(70, 95, 100, 20, "open dump file", false, new Runnable() {
			public void run() {
				launch(outPath + ".dump");
			}
		});
		/*if (args != null && args.length > 0) {
			for (int i = 0; i < args.length; i++) {
				println(args[i]);
				if (args[i].equals("-i") && i < args.length - 1) {
					if (true) {//exists(args[i] + 1)) {
						println("input: " + (args[i] + 1));
						argCont = "input: " + (args[i] + 1);
					}
				}
			}
		}*/
		/*String[] tkn = tokenise("$ff + ($10 - $50) * $02");
		tkn = getSubArray(tkn, 2);
		Expression.asm = this;
		Expression e = new Expression(tkn);
		try {
			e.prep(null, 0);
			println("Expression:");
			e.printInfo(1);
			println("Result: " + e.resolve(null, 0));
		} catch (CompilerError e1) {
			System.err.println(e1.message);
			e1.printStackTrace();
		}*/
		Expression.asm = this;
		ExpressionPart.asm = this;
		ImportedFile.asm = this;
	}

	public void draw() {
		background(255);
		textAlign(CORNER);
		fill(0);
		text("Source file", 5, 20);
		text("Assembly guide", 5, 50);
		text("Output file", 5, 80);
		text(srcPath, 155, 20);
		text(asmgPath, 155, 50);
		text(outPath, 155, 80);
		selectSrc.render();
		selectAsmg.render();
		selectOut.render();
		compile.render();
		openDump.render();
		filh(0xff0000);
		textAlign(CORNER);
		text(error0, 5, 135);
		text(error1, 5, 155);
		if (progEnabled) {
			fill(232);
			stroke(0);
			strokeWeight(1);
			rect(0, height - 40, width - 1, 39);
			noStroke();
			filh(0x00df00);
			rect(1, height - 39, ((float)width - 2f) * progress, 38);
			textAlign(CENTER);
			fill(0);
			text(progText, width / 2, height - 15);
		}
	}
	
	public void filh(int col) {
		fill(coloh(col));
	}
	
	public int coloh(int col) {
		return color((col >> 16) & 0xff, (col >> 8) & 0xff, col & 0xff);
	}
	
	public void strokh(int col) {
		fill(coloh(col));
	}

	boolean exists(String path) {
		File f = new File(path);
		return f.exists();
	}

	public void selSrc(File selected) {
		if (selected != null && selected.exists()) {
			srcPath = selected.getAbsolutePath();
			mousePressed = false;
		}
	}

	public void selAsmg(File selected) {
		if (selected != null && selected.exists()) {
			progEnabled = true;
			progText = "Parsing guide...";
			progress = 0;
			asmgPath = selected.getAbsolutePath();
			IS = new InstructionSet();
			String[] s = loadStrings(selected);
			for (int i = 0; i < s.length; i++) {
				if (s[i].charAt(0) != '@') {
					try {
						IS.addInstruction(s[i]);
						progress = ((float)i) / s.length;
					} catch(Throwable e) {
						if (e instanceof CompilerError) {
							error0 = "Syntax error in line " + (i + 1);
						}
						else if (e instanceof Exception) {
							error0 = "Exception in line " + (i + 1);
							error1 = e.getMessage();
						}
					}
				}
			}
			mousePressed = false;
			progEnabled = false;
		}
	}

	public void selOut(File selected) {
		if (selected != null) {
			outPath = selected.getAbsolutePath();
			mousePressed = false;
		}
	}

	void compile() {
		new Thread(new Runnable() {
			public void run() {
				error0 = "";
				error1 = "";
				try {
					compileProgram(loadStrings(srcPath), IS);
				} catch(CompilerError e) {
					error0 = "Syntax error in line " + e.line;
					error1 = e.message;
				}
			}
		}).start();
	}

	void saveOut(byte[] data) {
		println("Saving to " + outPath);
		String[] split = split(outPath, ".");
		String ext = split[split.length - 1];
		if (ext.equals("hex") || ext.equals("lhf")) {
			String s = "";
			for (int i = 0; i < data.length; i++) {
				s += hex(data[i]);
				if (i < data.length - 1) {
					s += " ";
				}
			}
			saveStrings(outPath, new String[]{"v2.0 raw", s});
		}
		else
		{
			saveBytes(outPath, data);
		}
	}
	
	public class CompilerError extends Throwable {
		private static final long serialVersionUID = -1285538276365577921L;
		int line;
		String message;
		CompilerError(int Sln, String Smsg) {
			line = Sln + 1;
			message = Smsg;
		}
	}

	public class InstructionSet {
		String[][] instructions;
		int[] lengths;
		int[] adresses;
		InstructionSet() {
			instructions = new String[0][0];
			adresses = new int[0];
			lengths = new int[0];
		}
		void addInstruction(String line) {
			String[] split = split(line, " ");
			instructions = (String[][]) expand(instructions, instructions.length + 1);
			instructions[instructions.length - 1] = tokeniseGuide(split(line, "\"")[1]);
			adresses = expand(adresses, adresses.length + 1);
			adresses[adresses.length - 1] = unhex(split[0]);
			lengths = expand(lengths, lengths.length + 1);
			lengths[lengths.length - 1] = calcLength(instructions[instructions.length - 1]);
			print("$" + hex(adresses[adresses.length - 1], 2) + ": ");
			println(join(tokeniseGuide(split(line, "\"")[1]), " "));
		}
		int calcLength(String[] tokens) {
			int len = 1;
			for (String s : tokens) {
				if (s.equals("%V%") || s.equals("%A%")) {
					len ++;
				}
			}
			return len;
		}
	}

	String[] tokeniseGuide(String raw) {
		raw = raw.replaceAll(" ", "\t");
		raw = split(raw, ";")[0];
		String s = "";
		String[] splitTokens = "# @ + - * = / , ( )".split(" ");
		boolean inString = false;
		boolean isDoubleQuotes = false;
		boolean isEscaped = false;
		for (int i = 0; i < raw.length(); i++) {
			char c = raw.charAt(i);
//			if (c == ',') {
//				s += " ";
//				s += c;
//			}
//			else if (c == '#') {
//				s += c;
//				s += " ";
//				if (i < raw.length() - 1) {
//					s += raw.charAt(i + 1);
//				}
//				i ++;
//			}
//			else if (c == '@') {
//				s += c;
//				s += " ";
//			}
//			else
//			{
//				s += c;
//			}
			boolean splitted = false;
			if (c == '\"') {
				if (inString && isDoubleQuotes && !isEscaped) {
					inString = false;
				}
				else if (!inString) {
					inString = true;
					isEscaped = false;
					isDoubleQuotes = true;
				}
			}
			else if (c == '\'') {
				if (inString && !isDoubleQuotes && !isEscaped) {
					inString = false;
				}
				else if (!inString) {
					inString = true;
					isEscaped = false;
					isDoubleQuotes = false;
				}
			}
			if (isEscaped) {
				isEscaped = false;
			}
			else if (c == '\\') {
				isEscaped = true;
			}
			if (inString) {
				if (c == '\t') {
					c = ' ';
				}
			}
			else
			{
				for (String tkn : splitTokens) {
					if (i < raw.length() - tkn.length() + 1) {
						boolean splitValid = true;
						for (int x = 0; x < tkn.length(); x++) {
							if (tkn.charAt(x) != raw.charAt(i + x)) {
								splitValid = false;
								break;
							}
						}
						if (splitValid) {
							splitted = true;
							if (i != 0) {
								s += '\t';
							}
							s +=  c + "\t";
							break;
						}
					}
				}
			}
			if (!splitted) {
				s += c;
			}
		}
		raw = s;
		s = "";
		boolean b = false;
		for (int i = 0; i < raw.length(); i++) {
			char c = raw.charAt(i);
			if (!b || c != '\t') {
				s += c;
			}
			b = c == '\t';
		}
		raw = s;
		s = "";
		b = false;
		for (int i = raw.length() - 1; i >= 0; i--) {
			char c = raw.charAt(i);
			if (b || c != '\t') {
				s = c + s;
				b = true;
			}
		}
		return split(s, "\t");
	}
	
	String[] tokenise(String raw) {
		return tokeniseGuide(raw);
	}
	
	String[] tokeniseOld(String raw) {
		raw = raw.replaceAll("\t", " ");
		raw = split(raw, ";")[0];
		String s = "";
		for (int i = 0; i < raw.length(); i++) {
			char c = raw.charAt(i);
			if (c == ',') {
				s += " ";
				s += c;
			} else if (c == '#') {
				s += c;
				s += " ";
				if (i < raw.length() - 1) {
					s += raw.charAt(i + 1);
				}
				i ++;
			} else if (c == '@') {
				s += c;
				s += " ";
			} else
			{
				s += c;
			}
		}
		raw = s;
		s = "";
		boolean b = false;
		for (int i = 0; i < raw.length(); i++) {
			char c = raw.charAt(i);
			if (!b || c != ' ') {
				s += c;
			}
			b = c == ' ';
		}
		raw = s;
		s = "";
		b = false;
		for (int i = raw.length() - 1; i >= 0; i--) {
			char c = raw.charAt(i);
			if (b || c != ' ') {
				s = c + s;
				b = true;
			}
		}
		return split(s, " ");
	}

	void compileProgram(String[] file, InstructionSet IS) throws CompilerError {
		progEnabled = true;
		progText = "Assembling program: Tokenizing...";
		println("----TOKENISING----");
		progress = 0;
		String[][] tokens = new String[file.length][];
		for (int i = 0; i < file.length; i++) {
			if (!isEmpty(file[i]) && !isComment(file[i])) {
				tokens[i] = tokenise(file[i]);
				printArray(tokens[i]);
			}
			else
			{
				tokens[i] = null;
			}
			progress = ((float)i) / file.length / 3f;
		}
		
		
		
		println("----FINDING IMPORTS----");
		progText = "Finding imports...";
		List<ImportedFile> imported = new ArrayList<ImportedFile>();
		for (int i = 0; i < tokens.length; i++) {
			progText = "Finding imports...";
			progress = ((float)i) / tokens.length;
			if (tokens[i] != null && tokens[i][0].equals("@") && tokens[i][1].equals("include")) {
				if (tokens.length < 3 || !tokens[i][2].startsWith("\"")) {
					throw new CompilerError(i, "@include requires a String path!");
				}
				String path = new File(srcPath).getParent() + "/" + string(unescString(tokens[i][2].substring(1, tokens[i][2].length() - 1)));
				println("Importing \"" + path + "\"...");
				ImportedFile f = new ImportedFile(path);
				f.line = i;
				imported.add(f);
				tokens[i] = null;
			}
		}
		
		
		
		println("----IMPORTING----");
		progText = "importing...";
		int importedLineOffset = 0;
		for (int i = 0; i < imported.size(); i++) {
			tokens = imported.get(i).insertTokens(tokens, imported.get(i).line + importedLineOffset);
			importedLineOffset += imported.get(i).tokens.length;
			progress = ((float)i + 1) / (imported.size());
		}
		
		
		
		println("----PASS 1----");
		progText = "Assembling program: pass 1...";
		int address = 0;
		Map<String, Integer> labels = new HashMap<String, Integer>();
		int[] compiled = new int[1024];
		int[] instructions = new int[tokens.length];
		boolean[] isInst = new boolean[tokens.length];
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i] != null && tokens[i].length > 0) {
				if (tokens[i][0].equals("*")) {
					if (!tokens[i][1].equals("=")) {
						throw new CompilerError(i, "Program start label must be a value!");
					}
					address = resolveExpression(getSubArray(tokens[i], 2), new HashMap<String, Integer>(), i);
				}
				else if (!tokens[i][0].equals("")) {
					if (labels.containsKey(tokens[i][0])) {
						println("Warning: label \"" + tokens[i][0] + "\" re-assigned!");
					}
					//labels = append(labels, tokens[i][0]);
					int labelAddress;
					if (tokens[i].length > 1 && tokens[i][1].equals("=")) {
						if (tokens[i].length < 2) {
							throw new CompilerError(i, "Missing EXPRESSION!");
						}
						//labelAdresses = append(labelAdresses, readVal(tokens[i][2], labels, labelAdresses, i));
						labelAddress = resolveExpression(getSubArray(tokens[i], 2), labels, i);
					}
					else
					{
						//labelAdresses = append(labelAdresses, adress);
						labelAddress = address;
					}
					labels.put(tokens[i][0], labelAddress);
					println("label \"" + tokens[i][0] + "\": " + labelAddress);
				}
			}
			if (tokens[i] != null) {
				if (tokens[i].length == 1) {
//					if (!tokens[i][0].equals("")) {
//						throw new CompilerError(i, "Error on \"" + tokens[i][0] + "\"");
//					}
				}
				else
				{
					if (tokens[i][1].equals("data") || tokens[i][1].equals("byte") || tokens[i][1].equals("bytes")) {
						//read data length
						boolean did = false;
						for (int x = 2; x < tokens[i].length; x ++) { //this needs to be improved later on
							if (!tokens[i][x].equals(",")) {
								if (!tokens[i][x].startsWith("\"") && !tokens[i][x].startsWith("\'") && !did) {
									address ++;
									did = true;
								}
							}
							else
							{
								did = false;
							}
							if (tokens[i][x].startsWith("\"") || tokens[i][x].startsWith("\'")) {
								println("String length: " + unescString(tokens[i][x].substring(1, tokens[i][x].length() - 1)).length);
								address += unescString(tokens[i][x].substring(1, tokens[i][x].length() - 1)).length;
							}
						}
					}
					else if(!tokens[i][1].equals("=")) { //we must ignore label definitions
						//find instruction
						boolean matchFound = false;
						for (int x = 0; x < IS.instructions.length; x++) {
							if (IS.instructions[x].length == tokens[i].length - 1) {
								boolean match = true;
								int instruction = 0;
								//check if tokens match
								for (int y = 0; y < IS.instructions[x].length; y++) {
									instruction = x;
									if (!matchTokens(tokens[i][y + 1], IS.instructions[x][y], labels) && !IS.instructions[x][y].equals("%A%") && !IS.instructions[x][y].equals("%V%")) {
										match = false;
										break;
									}
								}
								if (match) {
									instructions[i] = instruction;
									isInst[i] = true;
									//increment address for instruction word
									address ++;
									for (int y = 0; y < IS.instructions[x].length; y++) {
										if (IS.instructions[x][y].equals("%V%") || IS.instructions[x][y].equals("%A%")) {
											//increment address for data or address word
											address ++;
										}
									}
									matchFound = true;
									break;
								}
							}
						}
						if (!matchFound) {
							throw new CompilerError(i, "Instruction not found!");
						}
					}
				}
			}
			println(i + 1 + " / " + tokens.length);
			progress = ((float)i) / (tokens.length - 1f) / 3f + 1f / 3f;
			println("inst: " + hex(instructions[i], 2));
		}
		
		
		
		println("----PASS 2----");
		progText = "Assembling program: pass 2... ";
		AssemblyDump[] dump = new AssemblyDump[tokens.length];
		address = 0;
		for (int i = 0; i < tokens.length; i++) {
			println(i + 1);
			if (tokens[i] == null) {
				println("Empty line at " + (i + 1));
			}
			else
			{
				dump[i] = new AssemblyDump();
				dump[i].startAddress = address;
				dump[i].tokens = tokens[i];
				if (!isInst[i]) {
					//check data statements and garbages
					if (tokens[i].length > 1 && (tokens[i][1].equals("data") || tokens[i][1].equals("byte") || tokens[i][1].equals("bytes"))) {
						int tknStart = 2;
						for (int x = 2; x < tokens[i].length; x ++) { //this needs to be improved later on
							String[] mTokens = null;
							if (tokens[i][x].equals(",")) {
								mTokens = getSubArray(tokens[i], tknStart, x);
								tknStart = x + 1;
							}
							else if (x == tokens[i].length - 1) {
								mTokens = getSubArray(tokens[i], tknStart);
								tknStart = x + 1;
							}
							if (mTokens != null) {
								if (mTokens[0].startsWith("\"") || mTokens[0].startsWith("\'")) {
									Integer[] chars = unescString(mTokens[0].substring(1, mTokens[0].length() - 1));
									print("String: ");
									for (int y = 0; y < chars.length; y++) {
										print(((byte)(int)chars[y]) + " ");
										compiled[address] = (byte)(int)chars[y];
										address ++;
									}
								}
								else
								{
									compiled[address] = resolveExpression(mTokens, labels, i);
									address ++;
								}
							}
						}
					}
					else if (tokens[i][0].equals("*")) {
						address = readVal(tokens[i][2], null, i);
					}
				}
				else
				{
					int inst = instructions[i];
					compiled[address] = IS.adresses[inst];
					address ++;
					for (int x = 0; x < IS.instructions[inst].length; x++) {
						if (IS.instructions[inst][x].equals("%A%") || IS.instructions[inst][x].equals("%V%")) {
							compiled[address] = readVal(tokens[i][x + 1], labels, i);
							address ++;
						}
					}
				}
				dump[i].endAddress = address;
				dump[i].fetchCompiled(compiled);
			}
			progress = ((float)i) / ((float)tokens.length - 1) / 3f + 2f / 3f;
		}
		
		
		
		int[] dumpIndent = null;
		List<String> assemblyDump = new ArrayList<String>();
		for (AssemblyDump d : dump) {
			if (d != null) {
				d.genStrings();
				dumpIndent = d.checkIndentation(dumpIndent);
			}
		}
		for (AssemblyDump d : dump) {
			if (d != null) {
				assemblyDump.add(d.getString(dumpIndent));
			}
		}
		assemblyDump.add("");
		assemblyDump.add("Labels:");
		assemblyDump.add("");
		int labelIndent = 1;
		for (Map.Entry<String, Integer> e : labels.entrySet()) {
			if (e.getKey().length() >= labelIndent) {
				labelIndent = e.getKey().length() + 1;
			}
		}
		for (Map.Entry<String, Integer> e : labels.entrySet()) {
			String s = e.getKey();
			while (s.length() < labelIndent) {
				s += " ";
			}
			s += "$" + String.format("%02x", (int)e.getValue());
			assemblyDump.add(s);
		}
		assemblyDump.add("");
		assemblyDump.add("Program length: " + address + " / 256 bytes (" + (address / 2.56f) + "% of maximum size)");
		saveStrings(outPath + ".dump", assemblyDump.toArray(new String[0]));
		
		
		
		println("Final address: " + address + "\nProgram data:");
		for (int i = 0; i < compiled.length && i < address; i++) {
			println(hex(compiled[i], 2));
		}
		if (address > 256/*maxProgramLength*/) {
			throw new CompilerError(0, "The program is too long! " + address + " words out of " + 256 + " supported words long");
		}
		byte[] tmp = new byte[address];
		for (int i = 0; i < address; i++) {
			tmp[i] = (byte)compiled[i];
		}
		println("Done!");
		progText = "Saving...";
		saveOut(tmp);
		progText = "Done! Program uses " + (Math.round(tmp.length / 256f * 1000f) / 10f) + "% of memory (" + address + " words).";
	}
	
	public String string(Integer[] array) {
		char[] chars = new char[array.length];
		for (int i = 0; i < array.length; i++) {
			chars[i] = (char)(int)array[i];
		}
		return new String(chars);
	}
	
	Integer[] unescString(String raw) {
		List<Integer> chars = new ArrayList<Integer>();
		for (int y = 0; y < raw.length(); y++) {
			char c = raw.charAt(y);
			if (c == '\\') {
				switch(raw.charAt(y + 1)) {
					case('b'):
						c = '\b';
						chars.add((int)c);
						break;
					case('t'):
						c = '\t';
						chars.add((int)c);
						break;
					case('n'):
						c = '\n';
						chars.add((int)c);
						break;
					case('f'):
						c = '\f';
						chars.add((int)c);
						break;
					case('r'):
						c = '\r';
						chars.add((int)c);
						break;
					case('0'):
						chars.add(0);
						break;
					default:
						chars.add((int)raw.charAt(y + 1));
						break;
				}
				y ++;
			}
			else
			{
				chars.add((int)c);
			}
		}
		return chars.toArray(new Integer[0]);
	}

	boolean matchTokens(String src, String guide, Map<String, Integer> labels) {
		if (guide.equals("%V%") || guide.equals("%A%")) {
			if (src.charAt(0) == '%' || src.charAt(0) == '$') {
				return true;
			}
			else if ("0123456789-".indexOf(src.charAt(0)) >= 0) {
				return true;
			}
			else
			{
				return labels.containsKey(src);
			}
		}
		else
		{
			return guide.equalsIgnoreCase(src);
		}
	}

	boolean isComment(String s) {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ' && c != '\t') {
				return c == ';';
			}
		}
		return false;
	}

	boolean isEmpty(String s) {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ' && c != '\t') {
				return false;
			}
		}
		return true;
	}

	void printArray(String[] s) {
		for (int i = 0; i < s.length; i++) {
			if (s[i] == null) {
				print("null");
			} else
			{
				print("\"" + s[i] + "\"");
			}
			if (i < s.length - 1) {
				print(", ");
			}
		}
		println();
	}

	Object[] append(Object[] array, Object obj) {
		array = (Object[]) expand(array, array.length + 1);
		array[array.length - 1] = obj;
		return array;
	}
	
	String[] getSubArray(String[] raw, int start, int end) {
		String[] ar1 = new String[end - start];
		for (int i = 0; i < ar1.length; i++) {
			ar1[i] = raw[i + start];
		}
		return ar1;
	}
	
	String[] getSubArray(String[] raw, int start) {
		return getSubArray(raw, start, raw.length);
	}
	
	int resolveExpression(String[] tokens, Map<String, Integer> labels, int line) throws CompilerError {
		Expression e = new Expression(tokens);
		e.prep(labels, line);
		return e.resolve(labels, line);
	}
	
	
	int readVal(String raw, Map<String, Integer> labels, int line) throws CompilerError {
		String decc = "-0123456789";
		if (raw.charAt(0) == '\"' || raw.charAt(0) == '\'') {
			Integer[] arr = unescString(raw.substring(1, raw.length() - 1));
			if (arr.length != 1) {
				throw new CompilerError(line, "A character constant was expected!");
			}
			return arr[0];
		}
		if (raw.charAt(0) == '$') {
			return readHex(raw.substring(1), line);
		}
		else if (raw.charAt(0) == '%') {
			return readBin(raw.substring(1), line);
		}
		else if (raw.charAt(raw.length() - 1) == 'o' || raw.charAt(raw.length() - 1) == 'q') {
			return readOct(raw.substring(0, raw.length() - 1), line);
		}
		else if (decc.indexOf(raw.charAt(0)) >= 0) {
			return readDec(raw, line);
		}
		else if (labels != null && labels.containsKey(raw)) {
			return labels.get(raw);
		}
		else
		{
			throw new CompilerError(line, "Invalid label or literal \"" + raw + "\"");
		}
	}
	

	void verify(String lib, String raw, int line) throws CompilerError {
		lib = lib.toLowerCase();
		raw = raw.toLowerCase();
		for (int i = 0; i < raw.length(); i++) {
			int l = lib.indexOf(raw.charAt(i));
			if (l < 0) {
				throw new CompilerError(line, "Invalid literal " + raw + " here >" + raw.charAt(i) + "<");
			}
		}
	}

	int readHex(String raw, int line) throws CompilerError {
		verify("0123456789abcdef", raw, line);
		return unhex(raw);
	}

	int readBin(String raw, int line) throws CompilerError {
		verify("01", raw, line);
		return unbinary(raw);
	}

	int readOct(String raw, int line) throws CompilerError {
		String oct = "01234567";
		verify(oct, raw, line);
		int ret = 0;
		for (int i = 0; i < raw.length(); i++) {
			int l = oct.indexOf(raw.charAt(i));
			ret = (ret << 3) | l;
		}
		return ret;
	}

	int readDec(String raw, int line) throws CompilerError {
		if (raw.charAt(0) == '-') {
			if (raw.length() < 2) {
				throw new CompilerError(line, "Invalid literal " + raw + " here >" + raw.charAt(0) + "<");
			}
			verify("0123456789", raw.substring(1), line);
		}
		else
		{
			verify("0123456789", raw, line);
		}
		return Integer.parseInt(raw);
	}
	
	interface SidedRunnable {
		public void pre();
		public void post();
	}
	
	interface AdvRunnable {
		public Object run(Object in);
	}
	
	
	public class GUI {
		
		/**
		 * @author Julian Scheffers
		**/
		
		/*
		 * GUI, Copyright (�) Julian Scheffers, all rights reserved.
		 */
		
		
		
		int sketchWidth;
		int sketchHeight;
		
		AdvRunnable advRunnable(final Runnable S_simple) {
			return new AdvRunnable(){
				Runnable simple = S_simple;
				public Object run(Object o) {
					simple.run();
					return null;
				}
			};
		}
		
		public class Style {
			int fill;
			int stroke;
			float strokeWeight;
			Style(int S_fill, int S_stroke, float S_strokeWeight) {
				fill = S_fill;
				stroke = S_stroke;
				strokeWeight = S_strokeWeight;
			}
			PGraphics _set(PGraphics graphics) {
				graphics.fill(fill);
				graphics.stroke(stroke);
				graphics.strokeWeight(strokeWeight);
				return graphics;
			}
			void _set() {
				fill(fill);
				stroke(stroke);
				strokeWeight(strokeWeight);
			}
			void _rect(float x, float y, float width, float height) {
				fill(fill);
				stroke(stroke);
				strokeWeight(strokeWeight);
				rect(x, y, width, height);
			}
			void _ellipse(float x, float y, float width, float height) {
				fill(fill);
				stroke(stroke);
				strokeWeight(strokeWeight);
				ellipse(x, y, width, height);
			}
			void _line(float bx, float by, float ex, float ey) {
				fill(fill);
				stroke(stroke);
				strokeWeight(strokeWeight);
				line(bx, by, ex, ey);
			}
			void _rect(float x, float y, float width, float height, PGraphics graphics) {
				graphics.fill(fill);
				graphics.stroke(stroke);
				graphics.strokeWeight(strokeWeight);
				graphics.rect(x, y, width, height);
			}
			void _ellipse(float x, float y, float width, float height, PGraphics graphics) {
				graphics.fill(fill);
				graphics.stroke(stroke);
				graphics.strokeWeight(strokeWeight);
				graphics.ellipse(x, y, width, height);
			}
			void _line(float bx, float by, float ex, float ey, PGraphics graphics) {
				graphics.fill(fill);
				graphics.stroke(stroke);
				graphics.strokeWeight(strokeWeight);
				graphics.line(bx, by, ex, ey);
			}
		}
		
		public class TextStyle {
			int col;
			float size;
			int align;
			TextStyle(int S_col, float S_size, int S_align) {
				col = S_col;
				size = S_size;
				align = S_align;
			}
			TextStyle(int S_col) {
				col = S_col;
				size = 12;
				align = CORNER;
			}
			void _set() {
				fill(col);
				textSize(size);
				textAlign(align);
			}
			void _set(PGraphics graphics) {
				graphics.fill(col);
				graphics.textSize(size);
				graphics.textAlign(align);
			}
			void _text(String text, float x, float y) {
				fill(col);
				textSize(size);
				textAlign(align);
				text(text, x, y);
			}
			void _text(String text, float x, float y, PGraphics graphics) {
				graphics.fill(col);
				graphics.textSize(size);
				graphics.textAlign(align);
				graphics.text(text, x, y);
			}
		}
		
		public class Text {
			float x;
			float y;
			String text;
			TextStyle style;
			Text(float S_x, float S_y, String S_text, TextStyle S_style) {
				x = S_x;
				y = S_y;
				text = S_text;
				style = S_style;
			}
			Text(float S_x, float S_y, String S_text) {
				x = S_x;
				y = S_y;
				text = S_text;
				style = new TextStyle(0);
			}
			void display() {
				style._text(text, x, y);
			}
			void display(PGraphics p) {
				style._text(text, x, y, p);
			}
		}
		
		public class CheckboxStyle {
			Style check;
			Style cross;
			Style box;
			Style disabled;
			CheckboxStyle() {
				check = new Style(255, 0x00ff00, 1);
				cross = new Style(255, 0xff0000, 1);
				box = new Style(255, 127, 1);
				disabled = new Style(255, 192, 1);
			}
			CheckboxStyle(Style S_check, Style S_cross, Style S_box, Style S_disabled) {
				check = S_check;
				cross = S_cross;
				box = S_box;
				disabled = S_disabled;
			}
		}
		
		public class Checkbox {
			int x;
			int y;
			int width;
			int height;
			boolean value;
			boolean enabled;
			CheckboxStyle style;
			Runnable onChange;
			Checkbox(int S_x, int S_y, int S_width, int S_height) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				value = false;
				enabled = true;
				style = new CheckboxStyle();
				onChange = null;
			}
			Checkbox(int S_x, int S_y, int S_width, int S_height, CheckboxStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				value = false;
				enabled = true;
				style = S_style;
				onChange = null;
			}
			Checkbox(int S_x, int S_y, int S_width, int S_height, Runnable S_onChange) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				value = false;
				enabled = true;
				style = new CheckboxStyle();
				onChange = S_onChange;
			}
			Checkbox(int S_x, int S_y, int S_width, int S_height, CheckboxStyle S_style, Runnable S_onChange) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				value = false;
				enabled = true;
				style = S_style;
				onChange = S_onChange;
			}
			void display() {
				if (enabled) {
					if (value) {
						style.box._set();
						rect(x, y, width, height);
						style.check._set();
						line(x, y + height / 2, x + width / 2, y + height);
						line(x + width / 2, y + height, x + width, y);
					}
					else
					{
						style.box._set();
						rect(x, y, width, height);
						style.cross._set();
						line(x, y, x + width, y + height);
						line(x + width, y, x, y + height);
					}
				}
				else
				{
					style.disabled._set();
					rect(x, y, width, height);
					if (value) {
						line(x, y + height / 2, x + width / 2, y + height);
						line(x + width / 2, y + height, x + width, y);
					}
					else
					{
						line(x, y, x + width, y + height);
						line(x + width, y, x, y + height);
					}
				}
			}
			//do render in mousePressed
			void render() {
				if (enabled && mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height) value = !value;
			}
		}
		
		public class DropdownStyle {
			TextStyle text;
			TextStyle textDisabled;
			Style normal;
			Style disabled;
			int selected;
			int hover;
			DropdownStyle() {
				text = new TextStyle(0);
				textDisabled = new TextStyle(192);
				normal = new Style(255, 127, 1);
				disabled = new Style(255, 192, 1);
				selected = 192;
				hover = 0x60afff;
			}
			DropdownStyle(TextStyle S_text, TextStyle S_textDisabled, Style S_normal, Style S_disabled) {
				text = S_text;
				textDisabled = S_textDisabled;
				normal = S_normal;
				disabled = S_disabled;
			}
		}
		
		public class DropdownElement {
			String id;
			String value;
			DropdownElement(String S_id, String S_value) {
				id = S_id;
				value = S_value;
			}
		}
		
		public class Dropdown {
			int x;
			int y;
			int width;
			int height;
			int selectedIndex;
			boolean open;
			boolean enabled;
			DropdownElement[] elements;
			DropdownStyle style;
			SidedRunnable onChange;
			Dropdown(int S_x, int S_y, int S_width, int S_height, DropdownElement[] S_elements) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				selectedIndex = 0;
				open = false;
				enabled = true;
				elements = S_elements;
				style = new DropdownStyle();
				onChange = null;
			}
			Dropdown(int S_x, int S_y, int S_width, int S_height, DropdownElement[] S_elements, DropdownStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				selectedIndex = 0;
				open = false;
				enabled = true;
				elements = S_elements;
				style = S_style;
				onChange = null;
			}
			Dropdown(int S_x, int S_y, int S_width, int S_height, DropdownElement[] S_elements, SidedRunnable S_onChange) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				selectedIndex = 0;
				open = false;
				enabled = true;
				elements = S_elements;
				style = new DropdownStyle();
				onChange = S_onChange;
			}
			Dropdown(int S_x, int S_y, int S_width, int S_height, DropdownElement[] S_elements, DropdownStyle S_style, SidedRunnable S_onChange) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				selectedIndex = 0;
				open = false;
				enabled = true;
				elements = S_elements;
				style = S_style;
				onChange = S_onChange;
			}
			void render() {
				if (open && enabled) {
					style.normal._set();
					rect(x, y, width, height);
					line(x + width - height + height / 4, y + (height / 4) * 3, x + width - height / 2, y + height / 4);
					line(x + width - height / 4, y + (height / 4) * 3, x + width - height / 2, y + height / 4);
					int optionHeight = elements.length * (height / 3 * 2) + 1;
					int optiony = y;
					if (optiony + optionHeight > sketchHeight) optiony -= optiony + optionHeight - sketchHeight + 1;
					rect(x, optiony, width - height, optionHeight);
					for (int i = 0; i < elements.length; i++) {
						if (mouseX >= x && mouseX < x + width - height && mouseY >= optiony + (height / 3 * 2) * i && mouseY < optiony + (height / 3 * 2) * (i + 1)) {
							noStroke();
							fill(style.hover);
							rect(x + 1, optiony + (height / 3 * 2) * i + 1, width - height - 1, height / 3 * 2);
							if (mousePressed) {
								if (onChange != null) onChange.pre();
								selectedIndex = i;
								open = false;
								if (onChange != null) onChange.post();
							}
						}
						else if (selectedIndex == i) {
							noStroke();
							fill(style.selected);
							rect(x + 1, optiony + (height / 3 * 2) * i + 1, width - height - 1, height / 3 * 2);
						}
						style.text._text(elements[i].value, x + 5, optiony + (height / 3 * 2) * (i + 1));
					}
				}
				else
				{
					if (enabled) style.normal._set();
					else style.disabled._set();
					rect(x, y, width, height);
					line(x + width - height, y, x + width - height, y + height);
					line(x + width - height + height / 4, y + height / 4, x + width - height / 2, y + (height / 4) * 3);
					line(x + width - height / 4, y + height / 4, x + width - height / 2, y + (height / 4) * 3);
					if (enabled) style.text._set();
					else style.textDisabled._set();
					text(elements[selectedIndex].value, x + 5, y + height / 4 * 3);
				}
			}
			//do clicked in mousePressed
			void clicked() {
				if (enabled) {
					if (open) {
					int optionHeight = elements.length * (height / 3 * 2) + 1;
					int optiony = y;
					if (optiony + optionHeight > sketchHeight) optiony -= optiony + optionHeight - sketchHeight + 1;
						if (mouseX < x || mouseX > x + width - height || mouseY < optiony || mouseY > optiony + optionHeight) open = false;
					}
					else if (!open && mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height && elements.length >= 1) open = true;
				}
			}
		}
		
		public class TextInputStyle {
			TextStyle text;
			TextStyle textExample;
			TextStyle textDisabled;
			Style normal;
			Style selected;
			Style disabled;
			TextInputStyle() {
				text = new TextStyle(0);
				textExample = new TextStyle(127);
				textDisabled = new TextStyle(192);
				normal = new Style(255, 127, 1);
				selected = new Style(255, 0x60afff, 3);
				disabled = new Style(255, 192, 1);
			}
			TextInputStyle(TextStyle S_text, TextStyle S_textExample, TextStyle S_textDisabled, Style S_normal, Style S_selected, Style S_disabled) {
				text = S_text;
				textExample = S_textExample;
				textDisabled = S_textDisabled;
				normal = S_normal;
				selected = S_selected;
				disabled = S_disabled;
			}
		}
		
		public class TextInput {
			TextInputStyle style;
			int x;
			int y;
			int width;
			int height;
			int cursorPos;
			boolean password;
			boolean numeric;
			boolean selected;
			boolean enabled;
			String text;
			String example;
			int lastMillis;
			int barTimer;
			Runnable onEnter;
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = "";
				onEnter = null;
				style = new TextInputStyle();
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, TextInputStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = "";
				onEnter = null;
				style = S_style;
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, String S_example) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = S_example;
				onEnter = null;
				style = new TextInputStyle();
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, String S_example, TextInputStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = S_example;
				onEnter = null;
				style = S_style;
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, Runnable S_onEnter) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = "";
				onEnter = S_onEnter;
				style = new TextInputStyle();
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, TextInputStyle S_style, Runnable S_onEnter) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = "";
				onEnter = S_onEnter;
				style = S_style;
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, String S_example, Runnable S_onEnter) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = S_example;
				onEnter = S_onEnter;
				style = new TextInputStyle();
				barTimer = 0;
				lastMillis = millis();
			}
			TextInput(int S_x, int S_y, int S_width, int S_height, boolean S_password, boolean S_numeric, String S_example, TextInputStyle S_style, Runnable S_onEnter) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				password = S_password;
				numeric = S_numeric;
				selected = false;
				enabled = true;
				text = "";
				example = S_example;
				onEnter = S_onEnter;
				style = S_style;
				barTimer = 0;
				lastMillis = millis();
			}
			void display() {
				if (enabled && selected) style.selected._set();
				else if (enabled) style.normal._set();
				else style.disabled._set();
				rect(x, y, width, height);
				if (enabled && text.equals("") && !example.equals("")) style.textExample._set();
				else if (enabled) style.text._set();
				else style.textDisabled._set();
				if (text.equals("") && !example.equals("")) text(example, x + 3, y + height - 3);
				else text(text, x + 3, y + height - 3);
				String left = "";
				for (int i = 0; i < cursorPos; i++) {
					left += text.charAt(i);
				}
				strokeWeight(1);
				barTimer += millis() - lastMillis;
				lastMillis = millis();
				if (barTimer >= 1000) {
					barTimer -= 1000;
				}
				if (barTimer < 500 && selected) stroke(0, 255);
				else noStroke();
				line(x + 3 + textWidth(left), y + 2, x + 3 + textWidth(left), y + height - 2);
			}
			boolean mouseOver() {
				return mouseX >= x && mouseX <= x + width - 1 && mouseY >= y && mouseY <= y + height - 1;
			}
			//do select in mousePressed
			void select() {
				selected = mouseOver() && enabled;
			}
			//do render in keyPressed
			void render() {
				if (enabled && selected) {
					style.text._set();
					char pressed = key;
					int code = keyCode;
					if (pressed == ENTER || pressed == RETURN) {
						if (onEnter != null) onEnter.run();
					}
					else if (pressed == BACKSPACE) {
						String pre = "";
						String post = "";
						boolean isPost = false;
						for (int i = 0; i < text.length(); i++) {
							if (i == cursorPos) isPost = true;
							if (isPost) post += text.charAt(i);
							else if (i < cursorPos - 1) pre += text.charAt(i);
						}
						text = pre + post;
						if (cursorPos > 0) cursorPos --;
					}
					else if (pressed == '\f' || pressed == TAB);
					else if (pressed == CODED) {
						if (code == LEFT) {
							if (cursorPos > 0) cursorPos --;
						}
						else if (code == RIGHT) {
							if (cursorPos < text.length()) cursorPos ++;
						}
					}
					else if (textWidth(text + pressed) <= width - 6 && !(numeric && "0123456789".indexOf(pressed) < 0)) {
						String pre = "";
						String post = "";
						boolean isPost = false;
						for (int i = 0; i < text.length(); i++) {
							if (i == cursorPos) isPost = true;
							if (isPost) post += text.charAt(i);
							else pre += text.charAt(i);
						}
						text = pre + pressed + post;
						cursorPos ++;
					}
					barTimer = 0;
					lastMillis = millis();
				}
			}
		}
		
		public class ButtonStyle {
			TextStyle text;
			TextStyle textDisabled;
			Style normal;
			Style hover;
			Style pressed;
			Style disabled;
			ButtonStyle() {
				text = new TextStyle(0, 12, CENTER);
				textDisabled = new TextStyle(200, 12, CENTER);
				normal = new Style(255, 127, 1);
				hover = new Style(coloh(0x91c8ff), coloh(0x60afff), 3);
				pressed = new Style(coloh(0x3c3fe8), coloh(0x656691), 1);
				disabled = new Style(255, 200, 1);
			}
			ButtonStyle(TextStyle S_text, TextStyle S_textDisabled, Style S_normal, Style S_hover, Style S_pressed, Style S_disabled) {
				text = S_text;
				textDisabled = S_textDisabled;
				normal = S_normal;
				hover = S_hover;
				pressed = S_pressed;
				disabled = S_disabled;
				//make proper alignment stuffs (_textInRect()?)
				text.align = CENTER;
				textDisabled.align = CENTER;
			}
		}
		
		public class Button {
			int x;
			int y;
			int width;
			int height;
			String text;
			boolean enabled;
			boolean wasPressed;
			boolean dEdge;
			ButtonStyle style;
			AdvRunnable onPress;
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge, ButtonStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				text = S_text;
				enabled = true;
				style = S_style;
				onPress = null;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge) {
				x = S_x;
				y = S_y;
				if (S_width > ceil(textWidth(S_text))) width = S_width;
				else width = ceil(textWidth(S_text));
				height = S_height;
				text = S_text;
				enabled = true;
				style = new ButtonStyle();
				onPress = null;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge, ButtonStyle S_style, final Runnable S_onPress) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				text = S_text;
				enabled = true;
				style = S_style;
				onPress = advRunnable(S_onPress);
				wasPressed = false;
				dEdge = S_dEdge;
			}
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge, Runnable S_onPress) {
				x = S_x;
				y = S_y;
				if (S_width > ceil(textWidth(S_text))) width = S_width;
				else width = ceil(textWidth(S_text));
				height = S_height;
				text = S_text;
				enabled = true;
				style = new ButtonStyle();
				onPress = advRunnable(S_onPress);
				wasPressed = false;
				dEdge = S_dEdge;
			}
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge, ButtonStyle S_style, AdvRunnable S_onPress) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				text = S_text;
				enabled = true;
				style = S_style;
				onPress = S_onPress;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			Button(int S_x, int S_y, int S_width, int S_height, String S_text, boolean S_dEdge, AdvRunnable S_onPress) {
				x = S_x;
				y = S_y;
				if (S_width > ceil(textWidth(S_text))) width = S_width;
				else width = ceil(textWidth(S_text));
				height = S_height;
				text = S_text;
				enabled = true;
				style = new ButtonStyle();
				onPress = S_onPress;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			void render() {
				if (enabled) {
					if (pressed()) {
						style.pressed._rect(x, y, width, height);
						if (onPress != null && !wasPressed) onPress.run(this);
					}
					else if (mouseOver()) {
						style.hover._rect(x, y, width, height);
					}
					else
					{
						style.normal._rect(x, y, width, height);
					}
					if (!pressed() && wasPressed && dEdge && onPress != null) onPress.run(this);
					style.text._text(text, x + width / 2, y + height - 3);
					wasPressed = pressed();
				}
				else
				{
					style.disabled._rect(x, y, width, height);
					style.textDisabled._text(text, x + width / 2,	y + height - 3);
				}
			}
			void render(PApplet app, int mouseX, int mouseY, boolean mousePressed) {
				if (enabled) {
					if (pressed(mouseX, mouseY, mousePressed)) {
						style.pressed._rect(x, y, width, height, app.g);
						if (onPress != null && !wasPressed) onPress.run(this);
					}
					else if (mouseOver(mouseX, mouseY)) {
						style.hover._rect(x, y, width, height, app.g);
					}
					else
					{
						style.normal._rect(x, y, width, height, app.g);
					}
					if (!pressed(mouseX, mouseY, mousePressed) && wasPressed && dEdge && onPress != null) onPress.run(this);
					style.text._text(text, x + width / 2, y + height - 3, app.g);
					wasPressed = pressed(mouseX, mouseY, mousePressed);
				}
				else
				{
					style.disabled._rect(x, y, width, height, app.g);
					style.textDisabled._text(text, x + width / 2,	y + height - 3, app.g);
				}
			}
			void setEnabled(boolean S_enabled) {
				enabled = S_enabled;
			}
			boolean isEnabled() {
				return enabled;
			}
			boolean pressed() {
				return mousePressed && enabled && mouseOver();
			}
			boolean mouseOver() {
				return mouseX >= x && mouseX <= x + width - 1 && mouseY >= y && mouseY <= y + height - 1;
			}
			boolean pressed(int mouseX, int mouseY, boolean mousePressed) {
				return mousePressed && enabled && mouseOver(mouseX, mouseY);
			}
			boolean mouseOver(int mouseX, int mouseY) {
				return mouseX >= x && mouseX <= x + width - 1 && mouseY >= y && mouseY <= y + height - 1;
			}
		}
		
		public class TextureButtonStyle {
			PImage normal;
			PImage hover;
			PImage pressed;
			PImage disabled;
			TextureButtonStyle(PImage S_normal, PImage S_hover, PImage S_pressed, PImage S_disabled) {
				normal = S_normal;
				hover = S_hover;
				pressed = S_pressed;
				disabled = S_disabled;
			}
		}
		
		public class TextureButton {
			int x;
			int y;
			int width;
			int height;
			boolean enabled;
			boolean wasPressed;
			boolean dEdge;
			TextureButtonStyle style;
			AdvRunnable onPress;
			TextureButton(int S_x, int S_y, int S_width, int S_height, boolean S_dEdge, TextureButtonStyle S_style) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				enabled = true;
				style = S_style;
				onPress = null;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			TextureButton(int S_x, int S_y, int S_width, int S_height, boolean S_dEdge, TextureButtonStyle S_style, Runnable S_onPress) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				enabled = true;
				style = S_style;
				onPress = advRunnable(S_onPress);
				wasPressed = false;
				dEdge = S_dEdge;
			}
			TextureButton(int S_x, int S_y, int S_width, int S_height, boolean S_dEdge, TextureButtonStyle S_style, AdvRunnable S_onPress) {
				x = S_x;
				y = S_y;
				width = S_width;
				height = S_height;
				enabled = true;
				style = S_style;
				onPress = S_onPress;
				wasPressed = false;
				dEdge = S_dEdge;
			}
			void render() {
				if (enabled) {
					if (pressed()) {
						image(style.pressed, x, y, width, height);
						if (onPress != null && !wasPressed) onPress.run(this);
					}
					else if (mouseOver()) {
						image(style.hover, x, y, width, height);
					}
					else
					{
						image(style.normal, x, y, width, height);
					}
					if (!pressed() && wasPressed && dEdge && onPress != null) onPress.run(this);
					wasPressed = pressed();
				}
				else
				{
					image(style.disabled, x, y, width, height);
				}
			}
			void render(PGraphics p, int mouseX, int mouseY, boolean mousePressed) {
				if (enabled) {
					if (pressed(mouseX, mouseY, mousePressed)) {
						p.image(style.pressed, x, y, width, height);
						if (onPress != null && !wasPressed) onPress.run(this);
					}
					else if (mouseOver(mouseX, mouseY)) {
						p.image(style.hover, x, y, width, height);
					}
					else
					{
						p.image(style.normal, x, y, width, height);
					}
					if (!pressed(mouseX, mouseY, mousePressed) && wasPressed && dEdge && onPress != null) onPress.run(this);
					wasPressed = pressed(mouseX, mouseY, mousePressed);
				}
				else
				{
					p.image(style.disabled, x, y, width, height);
				}
			}
			void setEnabled(boolean S_enabled) {
				enabled = S_enabled;
			}
			boolean isEnabled() {
				return enabled;
			}
			boolean pressed() {
				return mousePressed && enabled && mouseOver();
			}
			boolean mouseOver() {
				return mouseX >= x && mouseX <= x + width - 1 && mouseY >= y && mouseY <= y + height - 1;
			}
			boolean pressed(int mouseX, int mouseY, boolean mousePressed) {
				return mousePressed && enabled && mouseOver(mouseX, mouseY);
			}
			boolean mouseOver(int mouseX, int mouseY) {
				return mouseX >= x && mouseX <= x + width - 1 && mouseY >= y && mouseY <= y + height - 1;
			}
		}
		
		public class ScrollBar {
			int x;
			int y;
			int length;
			int max;
			int value;
			boolean vertical;
			ScrollBar(boolean S_vertical, int S_x, int S_y, int S_length, int S_max) {
				x = S_x;
				y = S_y;
				length = S_length;
				vertical = S_vertical;
				max = S_max;
			}
			void display() {
				if (max > 0) {
					int barLength = length / max;
					if (barLength < 10) barLength = 10;
					float pixelPerValue = (length - barLength) / max;
					float pixelOffset = pixelPerValue * value;
					if (vertical) {
						noStroke();
						fill(127);
						ellipse(x + 5, y + 5 + pixelOffset, 10, 10);
						ellipse(x + 5, y + 5 + pixelOffset + barLength - 10, 10, 10);
						rect(x, y + 5 + pixelOffset, 10, barLength - 10);
					}
					else
					{
						
					}
				}
			}
			void scroll(int scroll) {
				value += scroll;
				if (value < 0) value = 0;
				if (value > max) value = max;
			}
		}
	}
	
}
