package assembler;

import java.util.Map;

import assembler.Assembler.CompilerError;

public class ExpressionPart {
	
	static Assembler asm;
	String type;
	int value;
	String operator;
	
	public ExpressionPart() {
		
	}
	
	public ExpressionPart(String token) {
		operator = token;
		switch(token) {
			default:
				type = "LITERAL";
				break;
			case("+"):
			case("-"):
			case("/"):
			case("*"):
				type = "OPERATOR";
				break;
		}
	}
	
	public ExpressionPart(int mValue) {
		type = "LITERAL";
		value = mValue;
		operator = "" + mValue;
	}
	
	public int resolve(Map<String, Integer> labels, int line) throws CompilerError {
		return asm.readVal(operator, labels, line);
	}
	
}
